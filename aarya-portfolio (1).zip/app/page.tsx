import Image from "next/image"
import { Github, Linkedin, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-teal-500 to-teal-700 py-20 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="md:w-2/3">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Aarya Sivakumar</h1>
              <p className="text-xl mb-6">Computer Science Student & Software Developer</p>
              <div className="flex items-center gap-2 mb-6">
                <Badge variant="outline" className="bg-white/10 text-white border-white/20 px-3 py-1">
                  Python
                </Badge>
                <Badge variant="outline" className="bg-white/10 text-white border-white/20 px-3 py-1">
                  HTML/CSS
                </Badge>
                <Badge variant="outline" className="bg-white/10 text-white border-white/20 px-3 py-1">
                  JavaScript
                </Badge>
              </div>
              <div className="flex gap-4">
                <Button variant="outline" className="bg-white/10 hover:bg-white/20 text-white border-white/20">
                  <Mail className="mr-2 h-4 w-4" /> Contact Me
                </Button>
                <Button variant="outline" className="bg-white/10 hover:bg-white/20 text-white border-white/20">
                  <Github className="mr-2 h-4 w-4" /> GitHub
                </Button>
                <Button variant="outline" className="bg-white/10 hover:bg-white/20 text-white border-white/20">
                  <Linkedin className="mr-2 h-4 w-4" /> LinkedIn
                </Button>
              </div>
            </div>
            <div className="md:w-1/3 flex justify-center">
              <div className="relative w-48 h-48 rounded-full overflow-hidden border-4 border-white/30">
                <Image
                  src="/images/aarya-profile.png"
                  alt="Aarya Sivakumar"
                  width={200}
                  height={200}
                  className="object-cover"
                  priority
                />
              </div>
            </div>
          </div>
        </div>
        <div
          className="absolute bottom-0 left-0 right-0 h-16 bg-white"
          style={{ clipPath: "polygon(0 100%, 100% 100%, 100% 0)" }}
        ></div>
      </section>

      {/* About Section */}
      <section className="py-16" id="about">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold mb-8 text-center text-gray-800">About Me</h2>
          <div className="max-w-3xl mx-auto text-lg text-gray-600">
            <p className="mb-4">
              I'm a high school student at Rouse High School with a passion for computer science and software
              development. Currently pursuing the Computer Science and Software Development pathway with a focus on App
              Development.
            </p>
            <p className="mb-4">
              Beyond academics, I'm actively involved in Model United Nations, where I've developed strong public
              speaking and negotiation skills. I also work as a USSF Soccer Referee, which has taught me valuable
              lessons in leadership, decision-making, and conflict resolution.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <div className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-teal-600" />
                <span>pdxaaryasiva@gmail.com</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-5 w-5 text-teal-600">📱</span>
                <span>+1 (503) 718-1323</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-5 w-5 text-teal-600">📍</span>
                <span>Leander, TX</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section className="py-16 bg-gray-50" id="education">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold mb-8 text-center text-gray-800">Education</h2>
          <div className="max-w-3xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle>Rouse High School</CardTitle>
                <CardDescription>Aug. 2024 - May 2028</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-2">
                  <span className="font-medium">Pathway:</span> Computer Science and Software Development: App
                  Development
                </p>
                <p className="mb-2">
                  <span className="font-medium">GPA:</span> Unweighted: 4.0 | Weighted: 5.3/6
                </p>
                <p className="mb-4">
                  <span className="font-medium">Relevant Coursework:</span>
                </p>
                <ul className="list-disc pl-5 space-y-1 text-gray-600">
                  <li>Advanced Algebra II</li>
                  <li>Advanced Biology</li>
                  <li>AP Human Geography</li>
                  <li>Advanced Spanish II</li>
                  <li>Advanced English I</li>
                  <li>Advanced Computer Science I</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Work Experience Section */}
      <section className="py-16" id="experience">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold mb-8 text-center text-gray-800">Work Experience</h2>
          <div className="max-w-3xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle>USSF Soccer Referee</CardTitle>
                <CardDescription>Leander, TX | Oct. 2024 - Present</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-gray-600">
                  <li>
                    Officiated games at recreational and competitive levels, ensuring fair play and adherence to USSF
                    rules.
                  </li>
                  <li>
                    Communicated professionally with coaches, players, and spectators to maintain a respectful game
                    environment.
                  </li>
                  <li>
                    Resolved on-field disputes with confidence and impartiality, demonstrating strong conflict
                    resolution skills.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16 bg-gray-50" id="projects">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold mb-8 text-center text-gray-800">Projects</h2>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Virtual Slot Machine Simulator</span>
                  <Badge className="ml-2 bg-teal-600">Python</Badge>
                </CardTitle>
                <CardDescription>Dec. 18 - Jan. 6</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-gray-600">
                  <li>
                    Developed a Python slot machine game with user deposits, betting mechanics, and random symbol
                    generation.
                  </li>
                  <li>
                    Implemented a win-checking algorithm to evaluate player outcomes based on symbol values and betting
                    lines.
                  </li>
                  <li>
                    Created a command-line interface for user interaction, enabling balance management and game results
                    display.
                  </li>
                </ul>
                <div className="mt-4">
                  <Button variant="outline" size="sm" className="text-teal-600 border-teal-600 hover:bg-teal-50">
                    <Github className="mr-2 h-4 w-4" /> View Code
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Banking Project Simulator</span>
                  <Badge className="ml-2 bg-teal-600">Python</Badge>
                </CardTitle>
                <CardDescription>Dec. 18 - Jan. 6</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-gray-600">
                  <li>
                    Developed a banking program simulation that allows users to deposit and withdraw funds, view their
                    balance, and access their transaction history.
                  </li>
                  <li>
                    Incorporated robust error handling to validate user inputs for deposits and withdrawals, ensuring
                    constraints such as minimum balance and maximum withdrawal limits.
                  </li>
                  <li>
                    Implemented a transaction history log, allowing users to see their deposits and withdrawals during
                    their banking session.
                  </li>
                </ul>
                <div className="mt-4">
                  <Button variant="outline" size="sm" className="text-teal-600 border-teal-600 hover:bg-teal-50">
                    <Github className="mr-2 h-4 w-4" /> View Code
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Awards & Extracurriculars Section */}
      <section className="py-16" id="awards">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold mb-8 text-center text-gray-800">Awards & Extracurriculars</h2>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle>Top Finalist, SICMUN 2025</CardTitle>
                <CardDescription>Georgetown, TX | Feb. 2025</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-gray-600">
                  <li>
                    Recognized as a Top Finalist among over 800 delegates including high school and college delegates
                    from more than five countries.
                  </li>
                  <li>
                    Lead a diverse group of over 30 delegates during committee sessions, articulating well-researched
                    positions and contributing to formulating comprehensive resolutions.
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Model United Nations</CardTitle>
                <CardDescription>Rouse High School | Aug. 2024 - Present</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-gray-600">
                  <li>
                    Represented multiple countries in high-stakes debates, effectively advocating for national interests
                    and contributing to the drafting of resolutions on global issues.
                  </li>
                  <li>
                    Developed strong public speaking and negotiation skills through delivering position papers and
                    engaging in collaborative discussions with diverse delegates.
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-16 bg-gray-50" id="skills">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold mb-8 text-center text-gray-800">Skills</h2>
          <div className="max-w-3xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-4 text-gray-800">Technical Skills</h3>
                <div className="space-y-3">
                  <div>
                    <p className="font-medium mb-1">Python</p>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: "90%" }}></div>
                    </div>
                  </div>
                  <div>
                    <p className="font-medium mb-1">HTML</p>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: "85%" }}></div>
                    </div>
                  </div>
                  <div>
                    <p className="font-medium mb-1">CSS</p>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: "80%" }}></div>
                    </div>
                  </div>
                  <div>
                    <p className="font-medium mb-1">JavaScript</p>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: "75%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-4 text-gray-800">Soft Skills</h3>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-center">
                    <span className="h-2 w-2 rounded-full bg-teal-600 mr-2"></span>
                    Communication
                  </li>
                  <li className="flex items-center">
                    <span className="h-2 w-2 rounded-full bg-teal-600 mr-2"></span>
                    Teamwork
                  </li>
                  <li className="flex items-center">
                    <span className="h-2 w-2 rounded-full bg-teal-600 mr-2"></span>
                    Leadership
                  </li>
                  <li className="flex items-center">
                    <span className="h-2 w-2 rounded-full bg-teal-600 mr-2"></span>
                    Time Management
                  </li>
                  <li className="flex items-center">
                    <span className="h-2 w-2 rounded-full bg-teal-600 mr-2"></span>
                    Attention to Detail
                  </li>
                  <li className="flex items-center">
                    <span className="h-2 w-2 rounded-full bg-teal-600 mr-2"></span>
                    Decision-Making
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16" id="contact">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold mb-8 text-center text-gray-800">Get In Touch</h2>
          <div className="max-w-md mx-auto">
            <Card>
              <CardContent className="pt-6">
                <form className="space-y-4">
                  <div className="grid grid-cols-1 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Name
                      </label>
                      <input
                        id="name"
                        placeholder="Your Name"
                        className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email
                      </label>
                      <input
                        id="email"
                        type="email"
                        placeholder="your.email@example.com"
                        className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="message" className="text-sm font-medium">
                        Message
                      </label>
                      <textarea
                        id="message"
                        placeholder="Your message here..."
                        rows={4}
                        className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                      ></textarea>
                    </div>
                  </div>
                  <Button className="w-full bg-teal-600 hover:bg-teal-700">Send Message</Button>
                </form>
                <div className="mt-6 flex justify-center space-x-4">
                  <Button variant="ghost" size="icon" className="text-gray-600 hover:text-teal-600">
                    <Github className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-gray-600 hover:text-teal-600">
                    <Linkedin className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="text-gray-600 hover:text-teal-600">
                    <Mail className="h-5 w-5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <p>© {new Date().getFullYear()} Aarya Sivakumar. All rights reserved.</p>
          <div className="mt-4 flex justify-center space-x-4">
            <a href="#about" className="hover:text-teal-400 transition-colors">
              About
            </a>
            <a href="#education" className="hover:text-teal-400 transition-colors">
              Education
            </a>
            <a href="#experience" className="hover:text-teal-400 transition-colors">
              Experience
            </a>
            <a href="#projects" className="hover:text-teal-400 transition-colors">
              Projects
            </a>
            <a href="#skills" className="hover:text-teal-400 transition-colors">
              Skills
            </a>
            <a href="#contact" className="hover:text-teal-400 transition-colors">
              Contact
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}
