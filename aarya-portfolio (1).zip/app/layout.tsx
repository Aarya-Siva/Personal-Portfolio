import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Aarya Sivakumar | Software Developer & Computer Science Student",
  description:
    "Professional portfolio of Aarya Sivakumar showcasing projects, skills, and experience in software development and computer science.",
  metadataBase: new URL("https://aarya-sivakumar.vercel.app"),
  openGraph: {
    title: "Aarya Sivakumar | Software Developer",
    description: "Professional portfolio showcasing my projects, skills, and experience",
    url: "https://aarya-sivakumar.vercel.app",
    siteName: "Aarya Sivakumar Portfolio",
    images: [
      {
        url: "/images/aarya-profile.png",
        width: 800,
        height: 600,
        alt: "Aarya Sivakumar",
      },
    ],
    locale: "en_US",
    type: "website",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}


import './globals.css'